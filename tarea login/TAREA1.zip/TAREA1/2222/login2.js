function validate()
{

var username=document.getElementById("username").value;
var password=document.getElementById("password").value;
if(username=="admin"&& password=="user")
{
    window.location="index.html";
}
else
{
    alert("usuario incorrecto")

    window.location.href="login2.html";
{
}
}
}

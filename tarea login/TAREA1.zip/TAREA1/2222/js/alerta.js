function Eliminar(){
    let alerta = document.getElementById("eliminar").value
    alert("Desea eliminar este registro?")
}